// Function to scan all font families and weights on a webpage
function scanAllFonts() {
  // Store declared fonts (from CSS)
  const declaredFonts = new Map();
  
  // Store loaded/available fonts
  const loadedFonts = new Map();
  
  // Helper function to check if a font family name is valid
  function isValidFontFamily(family) {
    if (!family) return false;
    
    // Filter out CSS keywords that aren't actual font names
    const invalidValues = ['inherit', 'initial', 'unset', 'none', 'auto', 'default'];
    return !invalidValues.includes(family.toLowerCase());
  }
  
  // Helper function to check if a font weight is valid
  function isValidFontWeight(weight) {
    if (!weight) return false;
    
    // Check if it's a valid numeric weight or a keyword
    const validKeywords = ['normal', 'bold', 'lighter', 'bolder'];
    return !isNaN(weight) || validKeywords.includes(weight);
  }
  
  // 1. Scan all stylesheets for font declarations
  Array.from(document.styleSheets).forEach(stylesheet => {
    try {
      // Access might be blocked for cross-origin stylesheets
      Array.from(stylesheet.cssRules || []).forEach(rule => {
        // Check if it's a style rule
        if (rule.style) {
          if (rule.style.fontFamily) {
            const families = rule.style.fontFamily.split(',');
            families.forEach(family => {
              const cleanFamily = family.trim().replace(/["']/g, '');
              if (isValidFontFamily(cleanFamily)) {
                if (!declaredFonts.has(cleanFamily)) {
                  declaredFonts.set(cleanFamily, new Set());
                }
                
                // Add font-weight if specified and valid
                if (rule.style.fontWeight && isValidFontWeight(rule.style.fontWeight)) {
                  declaredFonts.get(cleanFamily).add(rule.style.fontWeight);
                } else {
                  // Default weight
                  declaredFonts.get(cleanFamily).add('400');
                }
              }
            });
          }
        }
        // Check if it's a @font-face rule
        else if (rule.constructor.name === 'CSSFontFaceRule') {
          const family = rule.style.fontFamily?.replace(/["']/g, '');
          const weight = rule.style.fontWeight || '400';
          
          if (isValidFontFamily(family)) {
            if (!declaredFonts.has(family)) {
              declaredFonts.set(family, new Set());
            }
            declaredFonts.get(family).add(weight);
          }
        }
      });
    } catch (e) {
      console.log('Cannot access stylesheet:', e.message);
    }
  });
  
  // 2. Scan all elements for actually used fonts
  const allElements = document.querySelectorAll('*');
  allElements.forEach(element => {
    const style = window.getComputedStyle(element);
    const families = style.fontFamily.split(',');
    
    families.forEach(family => {
      const cleanFamily = family.trim().replace(/["']/g, '');
      if (isValidFontFamily(cleanFamily)) {
        if (!loadedFonts.has(cleanFamily)) {
          loadedFonts.set(cleanFamily, new Set());
        }
        
        if (isValidFontWeight(style.fontWeight)) {
          loadedFonts.get(cleanFamily).add(style.fontWeight);
        }
      }
    });
  });
  
  // 3. Check which fonts are loaded using the Font Loading API
  function checkFontLoaded(fontFamily, weight) {
    try {
      // Use a safe weight value
      const safeWeight = isValidFontWeight(weight) ? weight : '400';
      return document.fonts.check(`${safeWeight} 16px "${fontFamily}"`);
    } catch (e) {
      console.log(`Error checking font: ${fontFamily} ${weight}`, e);
      return false;
    }
  }
  
  // 4. Prepare results
  const result = {
    declaredFonts: {},
    loadedFonts: {},
    missingFonts: {}
  };
  
  // Process declared fonts
  declaredFonts.forEach((weights, family) => {
    const weightArray = Array.from(weights).sort((a, b) => {
      // Handle non-numeric weights for sorting
      if (isNaN(a) || isNaN(b)) {
        return String(a).localeCompare(String(b));
      }
      return Number(a) - Number(b);
    });
    
    result.declaredFonts[family] = weightArray.join(', ');
    
    // Check which weights are not loaded
    const missingWeights = [];
    weightArray.forEach(weight => {
      if (isValidFontWeight(weight) && !checkFontLoaded(family, weight)) {
        missingWeights.push(weight);
      }
    });
    
    if (missingWeights.length > 0) {
      result.missingFonts[family] = missingWeights.join(', ');
    }
  });
  
  // Process loaded fonts
  loadedFonts.forEach((weights, family) => {
    const weightArray = Array.from(weights).sort((a, b) => {
      if (isNaN(a) || isNaN(b)) {
        return String(a).localeCompare(String(b));
      }
      return Number(a) - Number(b);
    });
    
    result.loadedFonts[family] = weightArray.join(', ');
  });
  
  return result;
}

// Run the scan and log results
const fontAnalysis = scanAllFonts();

console.log("=== FONT ANALYSIS ===");
console.log("1. Declared Fonts (in CSS):");
console.table(fontAnalysis.declaredFonts);

console.log("2. Loaded Fonts (actually used):");
console.table(fontAnalysis.loadedFonts);

console.log("3. Missing Fonts (declared but not loaded):");
console.table(fontAnalysis.missingFonts);