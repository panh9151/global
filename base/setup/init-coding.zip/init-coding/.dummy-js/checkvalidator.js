async function validateHTML() {
    try {
        // Fetch source HTML giống khi nhấn Ctrl + U
        const response = await fetch(window.location.href, { method: "GET", credentials: "include" });
        const htmlContent = await response.text(); // Lấy HTML gốc từ server

        // Gửi HTML đến W3C Validator
        const validateResponse = await fetch("https://validator.w3.org/nu/?out=json", {
            method: "POST",
            headers: { "Content-Type": "text/html; charset=utf-8" },
            body: htmlContent
        });

        const result = await validateResponse.json();
        if (result.messages.length > 0) {
            const formattedMessages = result.messages.map(msg => ({
                Type: msg.type === "error" ? "❌ Error" : msg.type === "warning" ? "⚠️ Warning" : "ℹ️ Info",
                Message: msg.message,
                Line: msg.lastLine || "N/A",
                Column: msg.lastColumn || "N/A",
            }));

            console.table(formattedMessages);
        } else {
            console.log("%c✔ No validation errors found!", "color: green; font-weight: bold;");
        }
    } catch (error) {
        console.error("Error fetching HTML:", error);
    }
}
validateHTML();
