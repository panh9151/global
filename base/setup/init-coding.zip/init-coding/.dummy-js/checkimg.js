(function() {
    const images = document.querySelectorAll("img");

    // Thêm chỉ số index vào từng ảnh và highlight
    images.forEach((img, index) => {
        img.dataset.imgIndex = index; // Gán index vào dataset để dễ nhận diện
        img.style.outline = "2px solid red"; // Viền đỏ để highlight ảnh
        img.style.transition = "outline 0.3s ease-in-out";
    });

    const data = Array.from(images).map((img, index) => {
        const altText = img.getAttribute("alt");
        return {
            "Index": index, // Đánh số để dễ tìm ảnh
            "Image": img.outerHTML, // Hiển thị HTML của ảnh
            "Loading": img.getAttribute("loading") || "[❌ NO LOADING]",
            "Alt": altText ? altText : "[❌ MISSING ALT]"
        };
    });

    console.table(data);
    console.log("👉 Ảnh đã được highlight. Tìm số Index và nhập highlight(index) nếu muốn làm nổi bật lại.");

    // Hàm làm nổi bật ảnh theo index khi cần
    window.highlight = function(index) {
        const img = document.querySelector(`img[data-img-index="${index}"]`);
        if (!img) {
            console.warn("Không tìm thấy ảnh với index:", index);
            return;
        }

        img.style.outline = "4px solid blue"; // Highlight bằng viền xanh
        setTimeout(() => {
            img.style.outline = "2px solid red"; // Quay lại viền đỏ sau 2s
        }, 2000);
    };
})();
highlight(0);