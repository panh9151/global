function getLocalCSS() {
    let allCSS = ""; // Chuỗi chứa toàn bộ CSS từ local

    [...document.styleSheets].forEach(sheet => {
        if (sheet.href && sheet.href.startsWith(window.location.origin)) { // Chỉ lấy file từ local
            try {
                let cssRules = [...sheet.cssRules].map(rule => rule.cssText).join("\n");
                allCSS += `/* CSS từ: ${sheet.href} */\n${cssRules}\n\n`; // Thêm tên file vào trước CSS
            } catch (e) {
                console.warn("Không thể đọc CSS từ:", sheet.href);
            }
        }
    });

    console.log(allCSS); // In toàn bộ CSS từ các file local ra console
    return allCSS;
}

getLocalCSS();
