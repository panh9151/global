document.querySelectorAll(`
    a, button, input:not([type="hidden"]), select, textarea,
    [onclick], [tabindex]:not([tabindex="-1"]),
    [role="button"], [role="link"], [role="menuitem"],
    div[onclick], span[onclick], li[onclick], td[onclick]
`).forEach(el => {
    el.style.outline = "3px solid red";
    el.style.backgroundColor = "yellow";
});

(function() {
    let clickableElements = new Set();

    // 🔍 Tìm các phần tử có thuộc tính onclick
    document.querySelectorAll('[onclick]').forEach(el => clickableElements.add(el));

    // 🔍 Tìm các phần tử có tabindex >= 0 (có thể focus và click)
    document.querySelectorAll('[tabindex]').forEach(el => {
        if (el.getAttribute('tabindex') >= "0") clickableElements.add(el);
    });

    // 🔍 Tìm các phần tử có role="button", "link", "menuitem"
    document.querySelectorAll('[role="button"], [role="link"], [role="menuitem"]').forEach(el => clickableElements.add(el));

    // 🔍 Tìm các phần tử có sự kiện click thông qua addEventListener
    let allElements = document.querySelectorAll('*');
    allElements.forEach(el => {
        let listeners = getEventListeners(el);
        if (listeners.click) clickableElements.add(el);
    });

    // 🎨 Highlight tất cả phần tử có thể click
    clickableElements.forEach(el => {
        el.style.outline = "3px solid red";
        el.style.backgroundColor = "rgba(255, 0, 0, 0.2)";
    });

})();
