(function() {
    let hoverElements = new Set();

    // 🔍 Tìm phần tử có :hover trong CSS
    for (let sheet of document.styleSheets) {
        try {
            for (let rule of sheet.cssRules || []) {
                if (rule.selectorText && rule.selectorText.includes(':hover')) {
                    let elements = document.querySelectorAll(rule.selectorText.replace(':hover', ''));
                    elements.forEach(el => hoverElements.add(el));
                }
            }
        } catch (e) { /* Bỏ qua lỗi CORS nếu có */ }
    }

    // 🔍 Tìm phần tử có sự kiện mouseenter, mouseover
    document.querySelectorAll('*').forEach(el => {
        let events = getEventListeners(el);
        if (events.mouseenter || events.mouseover) {
            hoverElements.add(el);
        }
    });

    // 🎨 Highlight các phần tử tìm được
    hoverElements.forEach(el => {
        el.style.outline = "3px solid blue";
        el.style.backgroundColor = "rgba(0, 0, 255, 0.2)";
    });

    console.log("🔍 Danh sách phần tử có hover:", hoverElements);
})();
